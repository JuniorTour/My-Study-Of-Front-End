Hello, and welcome to the downloadable files for "Smashing CSS"!  We hope you'll enjoy messing around with them as much as we did.

The folders that came out of the zip file are organized by chapter.  Rather than include a separate file for each figure, though, we've provided the files that were the basis for those figures-- letting you follow along with the changes in the book and create your own crazy variants.  The folders also include any needed extra files, like external CSS and images.

And don't worry, it's intentional that there's no folder for Chapter 1.  Pretty much everything in that chapter is either a web site or a downloadable tool, so there wasn't anything to put in the folder.

Thanks for being a reader and creator of CSS!
